angular.module('constantModule',[])
.constant('SERVER',{
	"dev":"./data/",
	"pro":"./TRTDataInsight/",
	"isDev":true
})